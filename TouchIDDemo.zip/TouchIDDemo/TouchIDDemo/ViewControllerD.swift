//
//  ViewControllerD.swift
//  TouchIDDemo
//
//  Created by Vinoth on 10/16/19.
//  Copyright © 2019 Vinoth. All rights reserved.
//

import UIKit

class ViewControllerD: UIViewController {
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask{
        return .all
    }
    
    override var shouldAutorotate: Bool{
        return true
    }
    
    override var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation{
        return .landscapeRight
    }
}
