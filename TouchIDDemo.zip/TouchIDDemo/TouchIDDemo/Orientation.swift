import Foundation
import UIKit

extension UIViewController{
    
    func adjustOrientation() {
        if UIViewController.statusBarOrientation() != self.preferredInterfaceOrientationForPresentation
        {   UIDevice.current.setValue(self.preferredInterfaceOrientationForPresentation.rawValue, forKey: "orientation")
        }
    }

    func loopedTopViewController() -> UIViewController? {
        let window = UIApplication.shared.keyWindow
        var top = window?.rootViewController
        while true {
            if let presented = top?.presentedViewController {
                top = presented
            } else if let nav = top as? UINavigationController {
                top = nav.visibleViewController
            } else if let tab = top as? UITabBarController {
                top = tab.selectedViewController
            } else {
                break
            }
        }
        return top
    }//Nowhere logically used
    
    static func statusBarOrientation() -> UIInterfaceOrientation{
        return UIApplication.shared.statusBarOrientation
    }
}

extension UINavigationController{
    func adjustOrientationIfNeeded() {
        if UIViewController.statusBarOrientation() != self.topViewController?.preferredInterfaceOrientationForPresentation
        {   UIDevice.current.setValue(self.topViewController?.preferredInterfaceOrientationForPresentation.rawValue, forKey: "orientation")
        }
    }
}
