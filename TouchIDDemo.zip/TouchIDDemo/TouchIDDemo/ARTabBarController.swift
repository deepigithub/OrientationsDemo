import UIKit

class ARTabBarController: UITabBarController, UITabBarControllerDelegate {
    
    var correctlySelectedViewController:UIViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.delegate = self
        self.correctlySelectedViewController = self.viewControllers?.first
    }
    
    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        let selectedIndex = tabBar.items?.firstIndex(of: item) ?? 0
        if let currentViewController = self.viewControllers?[selectedIndex]
        {
            self.correctlySelectedViewController = currentViewController
            self.correctlySelectedViewController?.adjustOrientation()
        }
    }//This gets called when a different tab selected
}

extension ARTabBarController {
    override var supportedInterfaceOrientations : UIInterfaceOrientationMask {
        return self.correctlySelectedViewController?.supportedInterfaceOrientations ?? super.supportedInterfaceOrientations
    }
    
    override var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation {
        return self.correctlySelectedViewController?.preferredInterfaceOrientationForPresentation ?? super.preferredInterfaceOrientationForPresentation
    }
}//We cannot add this to UINavigationController extension, because it needs correctlySelectedViewController
